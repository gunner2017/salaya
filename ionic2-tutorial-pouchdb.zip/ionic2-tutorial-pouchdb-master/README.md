# ionic2-tutorial-pouchdb
This code is part of a tutorial on how to  use PouchDB and SQLite for local storage in Ionic 2 apps.

Read the tutorial here: [How To Use PouchDB + SQLite For Local Storage In Ionic 2](http://gonehybrid.com/how-to-use-pouchdb-sqlite-for-local-storage-in-ionic-2/)

For more tutorials on Ionic, check out my blog [Gone Hybrid](http://gonehybrid.com).

# How to run the app
After cloning the repo, run `npm install` followed by the `ionic serve` command.

Make sure you have all the tools installed, see [installation guide](http://gonehybrid.com/build-your-first-mobile-app-with-ionic-2-angular-2-part-2/).
